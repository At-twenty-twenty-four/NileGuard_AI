import { neon } from '@neondatabase/serverless';
import crypto from 'crypto';

export async function POST() {
  try {
    // This endpoint seeds a demo user directly into the Better Auth user table
    // For security, this should be restricted or removed in production
    
    if (!process.env.DATABASE_URL) {
      return Response.json({
        success: false,
        message: 'Database not configured',
      }, { status: 500 });
    }

    const sql = neon(process.env.DATABASE_URL);
    const demoEmail = 'test@ethioshield.com';
    const demoName = 'Demo User';
    const userId = crypto.randomUUID();

    // Check if demo user already exists in neon_auth.user table
    const existingUsers = await sql`
      SELECT id FROM neon_auth.user WHERE email = ${demoEmail} LIMIT 1
    `;

    if (existingUsers.length > 0) {
      return Response.json({
        success: true,
        message: 'Demo user already exists',
        email: demoEmail,
      });
    }

    // Insert into neon_auth.user table
    await sql`
      INSERT INTO neon_auth.user (id, email, name, "emailVerified", "createdAt", "updatedAt") 
      VALUES (${userId}, ${demoEmail}, ${demoName}, ${true}, ${new Date()}, ${new Date()})
    `;

    console.log('[v0] Demo user created with ID:', userId);

    return Response.json({
      success: true,
      message: 'Demo user created successfully',
      email: demoEmail,
    });
  } catch (error) {
    console.error('[v0] Error seeding demo user:', error);
    return Response.json({
      success: false,
      message: 'Failed to seed demo user',
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
