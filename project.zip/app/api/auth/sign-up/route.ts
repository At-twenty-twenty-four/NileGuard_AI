import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return Response.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return Response.json(
        { error: 'Password must be at least 8 characters' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await db.query.users.findFirst({
      where: eq(users.email, email),
    });

    if (existingUser) {
      return Response.json(
        { error: 'User already exists' },
        { status: 409 }
      );
    }

    // Create new user
    const newUser = await db.insert(users).values({
      email,
      name: email.split('@')[0],
      emailVerified: true, // For demo
    }).returning();

    // TODO: Hash password and store securely
    // TODO: Send verification email

    return Response.json({ success: true, user: newUser[0] });
  } catch (error) {
    console.error('Sign-up error:', error);
    return Response.json(
      { error: 'An error occurred during sign-up' },
      { status: 500 }
    );
  }
}
