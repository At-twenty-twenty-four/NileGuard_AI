import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { pqcKeys } from '@/lib/db/schema';

const RUST_SECURITY_SERVICE = process.env.RUST_SECURITY_SERVICE_URL || 'http://localhost:8001';

interface GenerateKeyRequest {
  algorithm: string;
  keySize: number;
}

export async function POST(request: NextRequest) {
  try {
    const body: GenerateKeyRequest = await request.json();

    // Validate input
    const validAlgorithms = ['CRYSTALS-Kyber', 'CRYSTALS-Dilithium', 'SPHINCS+'];
    if (!validAlgorithms.includes(body.algorithm)) {
      return NextResponse.json(
        { error: 'Invalid algorithm' },
        { status: 400 }
      );
    }

    // Generate key via Rust security service
    const securityResponse = await fetch(`${RUST_SECURITY_SERVICE}/crypto/keys/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        algorithm: body.algorithm,
        key_size: body.keySize,
      }),
    });

    if (!securityResponse.ok) {
      throw new Error(`Security service error: ${securityResponse.statusText}`);
    }

    const generatedKey = await securityResponse.json();

    // Store key metadata in database
    const keyRecord = await db.insert(pqcKeys).values({
      keyId: generatedKey.key_id,
      algorithm: body.algorithm,
      publicKey: generatedKey.public_key,
      privateKeyEncrypted: '', // Would be encrypted in production
      keySize: body.keySize,
      status: 'active',
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
    }).returning();

    return NextResponse.json({
      success: true,
      key: {
        id: keyRecord[0].id,
        keyId: keyRecord[0].keyId,
        algorithm: keyRecord[0].algorithm,
        publicKey: keyRecord[0].publicKey,
        status: keyRecord[0].status,
        createdAt: keyRecord[0].createdAt,
      },
    });
  } catch (error) {
    console.error('Key generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate key' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const algorithm = request.nextUrl.searchParams.get('algorithm');
    const status = request.nextUrl.searchParams.get('status') || 'active';

    const keys = await db.query.pqcKeys.findMany();

    const filtered = keys.filter((key) => {
      if (algorithm && key.algorithm !== algorithm) return false;
      if (status && key.status !== status) return false;
      return true;
    });

    return NextResponse.json({
      success: true,
      keys: filtered.map((key) => ({
        id: key.id,
        keyId: key.keyId,
        algorithm: key.algorithm,
        status: key.status,
        createdAt: key.createdAt,
        expiresAt: key.expiresAt,
      })),
      count: filtered.length,
    });
  } catch (error) {
    console.error('Failed to retrieve keys:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve keys' },
      { status: 500 }
    );
  }
}
