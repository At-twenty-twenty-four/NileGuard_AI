import { pgTable, text, integer, timestamp, boolean, uuid, jsonb, real, index, primaryKey } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name'),
  email: text('email').notNull().unique(),
  emailVerified: boolean('email_verified').default(false),
  image: text('image'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Sessions table
export const sessions = pgTable('sessions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  token: text('token').notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// User Roles and Permissions (RBAC)
export const userRoles = pgTable('user_roles', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: text('role').notNull(), // admin, analyst, manager, viewer
  permissions: jsonb('permissions').default('[]'),
  assignedAt: timestamp('assigned_at').defaultNow().notNull(),
  assignedBy: uuid('assigned_by').references(() => users.id),
}, (table) => ({
  userIdIdx: index('user_roles_user_id_idx').on(table.userId),
}));

// API Keys for bot/service accounts
export const apiKeys = pgTable('api_keys', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  keyHash: text('key_hash').notNull().unique(),
  name: text('name').notNull(),
  permissions: jsonb('permissions').default('[]'),
  lastUsedAt: timestamp('last_used_at'),
  expiresAt: timestamp('expires_at'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index('api_keys_user_id_idx').on(table.userId),
}));

// Webhook Configurations
export const webhooks = pgTable('webhooks', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  url: text('url').notNull(),
  events: jsonb('events').default('[]'), // threat_created, incident_created, action_executed
  secret: text('secret').notNull(),
  isActive: boolean('is_active').default(true),
  retryCount: integer('retry_count').default(3),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index('webhooks_user_id_idx').on(table.userId),
}));

// Threat Actors
export const threatActors = pgTable('threat_actors', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  nickname: text('nickname'),
  country: text('country'),
  firstSeen: timestamp('first_seen'),
  lastSeen: timestamp('last_seen'),
  sophistication: text('sophistication').default('unknown'), // novice, intermediate, advanced, expert
  motivations: jsonb('motivations').default('[]'), // financial, political, espionage, etc
  description: text('description'),
  knownTactics: jsonb('known_tactics').default('[]'),
  cvss: real('cvss').default(0),
  threatLevel: text('threat_level').default('medium'), // critical, high, medium, low
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  nameIdx: index('threat_actors_name_idx').on(table.name),
  countryIdx: index('threat_actors_country_idx').on(table.country),
}));

// Security Incidents/Alerts
export const securityAlerts = pgTable('security_alerts', {
  id: uuid('id').primaryKey().defaultRandom(),
  threatActorId: uuid('threat_actor_id').references(() => threatActors.id, { onDelete: 'set null' }),
  alertType: text('alert_type').notNull(), // intrusion, malware, phishing, data_exfiltration
  severity: text('severity').default('medium'), // critical, high, medium, low, info
  status: text('status').default('open'), // open, investigating, contained, resolved
  title: text('title').notNull(),
  description: text('description'),
  sourceIp: text('source_ip'),
  targetSystem: text('target_system'),
  confidenceScore: real('confidence_score').default(0), // 0-100, AI confidence
  detectionMethod: text('detection_method'), // intrusion_detection, malware_scan, phishing_filter, etc
  metadata: jsonb('metadata').default('{}'),
  aiRecommendation: text('ai_recommendation'),
  aiActionTaken: text('ai_action_taken'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  typeIdx: index('security_alerts_type_idx').on(table.alertType),
  severityIdx: index('security_alerts_severity_idx').on(table.severity),
  statusIdx: index('security_alerts_status_idx').on(table.status),
  createdIdx: index('security_alerts_created_idx').on(table.createdAt),
}));

// Malware Analysis Records
export const malwareAnalysis = pgTable('malware_analysis', {
  id: uuid('id').primaryKey().defaultRandom(),
  hash: text('hash').notNull().unique(),
  hashType: text('hash_type'), // md5, sha256, ssdeep
  filename: text('filename'),
  fileSize: integer('file_size'),
  fileType: text('file_type'),
  detectionRate: real('detection_rate'),
  malwareFamily: text('malware_family'),
  behavior: jsonb('behavior').default('[]'),
  ioc: jsonb('ioc').default('[]'), // Indicators of Compromise
  threatLevel: text('threat_level').default('unknown'),
  firstSeen: timestamp('first_seen').defaultNow(),
  lastSeen: timestamp('last_seen'),
  analysisReport: text('analysis_report'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  hashIdx: index('malware_analysis_hash_idx').on(table.hash),
  familyIdx: index('malware_analysis_family_idx').on(table.malwareFamily),
}));

// Intrusion Detection Events
export const intrusionEvents = pgTable('intrusion_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  eventType: text('event_type').notNull(), // port_scan, brute_force, privilege_escalation, lateral_movement
  sourceIp: text('source_ip'),
  destinationIp: text('destination_ip'),
  port: integer('port'),
  protocol: text('protocol'), // TCP, UDP, ICMP
  payloadHash: text('payload_hash'),
  suspiciousScore: real('suspicious_score').default(0),
  associatedActorId: uuid('associated_actor_id').references(() => threatActors.id),
  metadata: jsonb('metadata').default('{}'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  sourceIpIdx: index('intrusion_events_source_ip_idx').on(table.sourceIp),
  eventTypeIdx: index('intrusion_events_type_idx').on(table.eventType),
}));

// Phishing Detection
export const phishingRecords = pgTable('phishing_records', {
  id: uuid('id').primaryKey().defaultRandom(),
  url: text('url').notNull(),
  domain: text('domain'),
  senderEmail: text('sender_email'),
  targetRecipients: jsonb('target_recipients').default('[]'),
  subject: text('subject'),
  bodyPreview: text('body_preview'),
  suspicionScore: real('suspicion_score').default(0),
  targetedOrganization: text('targeted_organization'),
  threat: text('threat'), // credential_harvesting, malware_delivery, social_engineering
  status: text('status').default('detected'), // detected, reported, confirmed_phishing, false_positive
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  urlIdx: index('phishing_records_url_idx').on(table.url),
  domainIdx: index('phishing_records_domain_idx').on(table.domain),
}));

// Autonomous Response Actions
export const autonomousActions = pgTable('autonomous_actions', {
  id: uuid('id').primaryKey().defaultRandom(),
  alertId: uuid('alert_id').references(() => securityAlerts.id, { onDelete: 'cascade' }),
  actionType: text('action_type').notNull(), // isolate_system, block_ip, quarantine_file, kill_process, etc
  actionStatus: text('action_status').default('pending'), // pending, executing, completed, failed
  targetResource: text('target_resource'),
  reason: text('reason'),
  confidenceScore: real('confidence_score').default(0),
  rollbackCapable: boolean('rollback_capable').default(true),
  executedAt: timestamp('executed_at'),
  result: jsonb('result').default('{}'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Audit Logs
export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'set null' }),
  action: text('action').notNull(),
  resourceType: text('resource_type'),
  resourceId: text('resource_id'),
  changes: jsonb('changes').default('{}'),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index('audit_logs_user_id_idx').on(table.userId),
  actionIdx: index('audit_logs_action_idx').on(table.action),
  createdIdx: index('audit_logs_created_idx').on(table.createdAt),
}));

// Post-Quantum Cryptography Key Management
export const pqcKeys = pgTable('pqc_keys', {
  id: uuid('id').primaryKey().defaultRandom(),
  keyId: text('key_id').notNull().unique(),
  algorithm: text('algorithm').notNull(), // CRYSTALS-Kyber, CRYSTALS-Dilithium, SPHINCS+, etc
  publicKey: text('public_key').notNull(),
  privateKeyEncrypted: text('private_key_encrypted'), // Stored encrypted
  keySize: integer('key_size'),
  status: text('status').default('active'), // active, retired, compromised
  createdAt: timestamp('created_at').defaultNow().notNull(),
  rotatedAt: timestamp('rotated_at'),
  expiresAt: timestamp('expires_at'),
}, (table) => ({
  keyIdIdx: index('pqc_keys_key_id_idx').on(table.keyId),
  algorithmIdx: index('pqc_keys_algorithm_idx').on(table.algorithm),
}));

// Digital Twin Network Simulation
export const digitalTwinNodes = pgTable('digital_twin_nodes', {
  id: uuid('id').primaryKey().defaultRandom(),
  simulationId: uuid('simulation_id'),
  nodeType: text('node_type').notNull(), // server, workstation, firewall, router, iot_device
  nodeIp: text('node_ip').notNull(),
  nodeName: text('node_name'),
  osType: text('os_type'),
  osVersion: text('os_version'),
  services: jsonb('services').default('[]'),
  vulnerabilities: jsonb('vulnerabilities').default('[]'),
  state: text('state').default('healthy'), // healthy, compromised, isolated
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Threat Intelligence Feed
export const threatIntelFeed = pgTable('threat_intel_feed', {
  id: uuid('id').primaryKey().defaultRandom(),
  source: text('source').notNull(),
  feedType: text('feed_type').notNull(), // ioc_feed, actor_profile, campaign, vulnerability
  content: jsonb('content').notNull(),
  severity: text('severity').default('medium'),
  confidence: real('confidence').default(0),
  ingestionTime: timestamp('ingestion_time').defaultNow().notNull(),
  lastUpdated: timestamp('last_updated').defaultNow(),
}, (table) => ({
  sourceIdx: index('threat_intel_feed_source_idx').on(table.source),
  feedTypeIdx: index('threat_intel_feed_type_idx').on(table.feedType),
  ingestionIdx: index('threat_intel_feed_ingestion_idx').on(table.ingestionTime),
}));

// Incidents/Cases (Enhanced)
export const incidents = pgTable('incidents', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: text('title').notNull(),
  description: text('description'),
  severity: text('severity').notNull(), // critical, high, medium, low
  status: text('status').default('open'), // open, investigating, contained, resolved, closed
  priority: integer('priority').default(0),
  startTime: timestamp('start_time').defaultNow().notNull(),
  endTime: timestamp('end_time'),
  assignedTo: uuid('assigned_to').references(() => users.id),
  relatedAlerts: jsonb('related_alerts').default('[]'),
  affectedAssets: jsonb('affected_assets').default('[]'),
  rootCause: text('root_cause'),
  resolution: text('resolution'),
  createdBy: uuid('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  statusIdx: index('incidents_status_idx').on(table.status),
  severityIdx: index('incidents_severity_idx').on(table.severity),
  assignedIdx: index('incidents_assigned_to_idx').on(table.assignedTo),
}));

// Incident Timeline/Events
export const incidentEvents = pgTable('incident_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  incidentId: uuid('incident_id').notNull().references(() => incidents.id, { onDelete: 'cascade' }),
  eventType: text('event_type').notNull(), // detection, investigation, action, resolution
  description: text('description').notNull(),
  actionTaken: text('action_taken'),
  updatedBy: uuid('updated_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  incidentIdIdx: index('incident_events_incident_id_idx').on(table.incidentId),
}));

// Threat Indicators (STIX Compatible)
export const threatIndicators = pgTable('threat_indicators', {
  id: uuid('id').primaryKey().defaultRandom(),
  indicatorType: text('indicator_type').notNull(), // ipv4, domain, file_hash, email, url
  value: text('value').notNull(),
  tlp: text('tlp').default('white'), // white, green, amber, red
  confidence: real('confidence').default(0),
  severity: text('severity').default('medium'),
  source: text('source').notNull(),
  description: text('description'),
  validFrom: timestamp('valid_from').defaultNow(),
  validUntil: timestamp('valid_until'),
  metadata: jsonb('metadata').default('{}'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  valueIdx: index('threat_indicators_value_idx').on(table.value),
  typeIdx: index('threat_indicators_type_idx').on(table.indicatorType),
}));

// System Health & Metrics
export const systemMetrics = pgTable('system_metrics', {
  id: uuid('id').primaryKey().defaultRandom(),
  metricType: text('metric_type').notNull(), // threat_detection_rate, response_time, false_positive_rate
  metricName: text('metric_name').notNull(),
  value: real('value').notNull(),
  unit: text('unit'),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
}, (table) => ({
  typeIdx: index('system_metrics_type_idx').on(table.metricType),
  timestampIdx: index('system_metrics_timestamp_idx').on(table.timestamp),
}));

// Compliance Records
export const complianceRecords = pgTable('compliance_records', {
  id: uuid('id').primaryKey().defaultRandom(),
  standard: text('standard').notNull(), // SOC2, ISO27001, PCI-DSS, HIPAA
  controlName: text('control_name').notNull(),
  status: text('status').notNull(), // compliant, non_compliant, not_applicable
  evidence: text('evidence'),
  lastAssessment: timestamp('last_assessment'),
  nextAssessment: timestamp('next_assessment'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Relations
export const threatActorsRelations = relations(threatActors, ({ many }) => ({
  alerts: many(securityAlerts),
  intrusionEvents: many(intrusionEvents),
}));

export const securityAlertsRelations = relations(securityAlerts, ({ one, many }) => ({
  threatActor: one(threatActors, {
    fields: [securityAlerts.threatActorId],
    references: [threatActors.id],
  }),
  autonomousActions: many(autonomousActions),
}));

export const autonomousActionsRelations = relations(autonomousActions, ({ one }) => ({
  alert: one(securityAlerts, {
    fields: [autonomousActions.alertId],
    references: [securityAlerts.id],
  }),
}));

export const incidentsRelations = relations(incidents, ({ one, many }) => ({
  assignedUser: one(users, {
    fields: [incidents.assignedTo],
    references: [users.id],
  }),
  creator: one(users, {
    fields: [incidents.createdBy],
    references: [users.id],
  }),
  events: many(incidentEvents),
}));

export const incidentEventsRelations = relations(incidentEvents, ({ one }) => ({
  incident: one(incidents, {
    fields: [incidentEvents.incidentId],
    references: [incidents.id],
  }),
  updatedByUser: one(users, {
    fields: [incidentEvents.updatedBy],
    references: [users.id],
  }),
}));

export const userRolesRelations = relations(userRoles, ({ one }) => ({
  user: one(users, {
    fields: [userRoles.userId],
    references: [users.id],
  }),
  assignedByUser: one(users, {
    fields: [userRoles.assignedBy],
    references: [users.id],
  }),
}));

export const apiKeysRelations = relations(apiKeys, ({ one }) => ({
  user: one(users, {
    fields: [apiKeys.userId],
    references: [users.id],
  }),
}));

export const webhooksRelations = relations(webhooks, ({ one }) => ({
  user: one(users, {
    fields: [webhooks.userId],
    references: [users.id],
  }),
}));
