import { drizzle } from 'drizzle-orm/neon-http';
import { neon } from '@neondatabase/serverless';
import * as schema from './schema';

let db: any = null;

function getDb() {
  if (!db && process.env.DATABASE_URL) {
    const client = neon(process.env.DATABASE_URL);
    db = drizzle(client, { schema });
  }
  return db;
}

// For direct imports
if (process.env.DATABASE_URL) {
  db = getDb();
}

export { db, getDb };
