import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { db } from "./db";
import { users, sessions } from "./db/schema";

// Initialize auth only if database is available
let auth: any = null;

if (db) {
  auth = betterAuth({
    database: drizzleAdapter(db, {
      provider: "pg",
      usersTable: users,
      sessionsTable: sessions,
    }),
    emailAndPassword: {
      enabled: true,
      autoSignInAfterSignUp: true,
    },
    session: {
      expiresIn: 60 * 60 * 24 * 7, // 7 days
      cookieCache: {
        enabled: true,
        maxAge: 5 * 60, // 5 minutes
      },
    },
    appName: "EthioShield",
    baseURL: process.env.BETTER_AUTH_URL || "http://localhost:3000",
    secret: process.env.NEON_AUTH_COOKIE_SECRET,
  });
}

export { auth };
export type Session = any;
