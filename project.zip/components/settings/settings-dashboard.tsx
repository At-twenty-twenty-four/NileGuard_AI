'use client';

import { useState } from 'react';
import { Settings, Lock, Database, Power, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface SettingsProps {
  locale: string;
}

export function SettingsDashboard({ locale }: SettingsProps) {
  const [settings, setSettings] = useState({
    orgName: 'EthioShield Organization',
    email: 'admin@ethioshield.com',
    alertThreshold: 70,
    autoResponse: true,
    loggingEnabled: true,
    dataRetention: 90,
  });

  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSave = async () => {
    setSaveStatus('saving');
    await new Promise(resolve => setTimeout(resolve, 500));
    setSaveStatus('saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const texts = {
    en: {
      title: 'Organization Settings',
      description: 'Configure platform behavior, alerts, and security policies',
      general: 'General Settings',
      security: 'Security & Monitoring',
      alerts: 'Alert Configuration',
      dataManagement: 'Data Management',
      orgName: 'Organization Name',
      email: 'Administrator Email',
      alertThreshold: 'Alert Threshold (%)',
      autoResponse: 'Enable Autonomous Response',
      loggingEnabled: 'Enable Audit Logging',
      dataRetention: 'Data Retention (Days)',
      saveChanges: 'Save Changes',
      advancedSettings: 'Advanced Settings',
      apiKeys: 'API Keys',
      integrations: 'Integrations',
      saved: 'Settings saved successfully',
    },
    am: {
      title: 'ድርጅታዊ ቅንጅቶች',
      description: 'መድረክ ባህሪ, ማወሳወሶች, እና ደህንነት ፖሊሲዎች ያቋቁሙ',
      general: 'አጠቃላይ ቅንጅቶች',
      security: 'ደህንነት እና ክትትል',
      alerts: 'ማወሳወስ ቅንጅት',
      dataManagement: 'ውሂብ ግንኙነት',
      orgName: 'ድርጅታዊ ስም',
      email: 'አስተዳዳሪ ኢሜል',
      alertThreshold: 'ማወሳወስ ደረጃ (%)',
      autoResponse: 'ራስ-ሰር ምላሽ ያስቻሉ',
      loggingEnabled: 'የመርምር ምዝግብ ያስቻሉ',
      dataRetention: 'ውሂብ ጉቦ (ቀናት)',
      saveChanges: 'ለውጦችን ያስቀምጡ',
      advancedSettings: 'የላቀ ቅንጅቶች',
      apiKeys: 'API ቁልፎች',
      integrations: 'ውህደቶች',
      saved: 'ቅንጅቶች በተሳካ ሁኔታ ተቀምጠዋል',
    },
  };

  const t = texts[locale as keyof typeof texts] || texts.en;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">{t.title}</h1>
        <p className="text-muted-foreground">{t.description}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Settings */}
        <div className="lg:col-span-2 space-y-6">
          {/* General Settings */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              {t.general}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {t.orgName}
                </label>
                <Input
                  value={settings.orgName}
                  onChange={(e) => setSettings({ ...settings, orgName: e.target.value })}
                  className="bg-background/50 border-primary/30"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {t.email}
                </label>
                <Input
                  type="email"
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  className="bg-background/50 border-primary/30"
                />
              </div>
            </div>
          </div>

          {/* Security & Monitoring */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Lock className="w-5 h-5 text-accent" />
              {t.security}
            </h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-primary/10">
                <div>
                  <p className="font-medium text-foreground">{t.autoResponse}</p>
                  <p className="text-sm text-muted-foreground">Automatically respond to detected threats</p>
                </div>
                <button
                  onClick={() => setSettings({ ...settings, autoResponse: !settings.autoResponse })}
                  className={`p-2 rounded-lg transition ${
                    settings.autoResponse ? 'bg-primary/20 text-primary' : 'bg-background text-muted-foreground'
                  }`}
                >
                  <Power className="w-6 h-6" />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-primary/10">
                <div>
                  <p className="font-medium text-foreground">{t.loggingEnabled}</p>
                  <p className="text-sm text-muted-foreground">Enable comprehensive audit logging</p>
                </div>
                <button
                  onClick={() => setSettings({ ...settings, loggingEnabled: !settings.loggingEnabled })}
                  className={`p-2 rounded-lg transition ${
                    settings.loggingEnabled ? 'bg-primary/20 text-primary' : 'bg-background text-muted-foreground'
                  }`}
                >
                  <Power className="w-6 h-6" />
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {t.alertThreshold}
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.alertThreshold}
                  onChange={(e) => setSettings({ ...settings, alertThreshold: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Low</span>
                  <span className="font-semibold text-primary">{settings.alertThreshold}%</span>
                  <span>High</span>
                </div>
              </div>
            </div>
          </div>

          {/* Data Management */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Database className="w-5 h-5 text-orange-500" />
              {t.dataManagement}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {t.dataRetention}
                </label>
                <Input
                  type="number"
                  value={settings.dataRetention}
                  onChange={(e) => setSettings({ ...settings, dataRetention: parseInt(e.target.value) })}
                  className="bg-background/50 border-primary/30"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Data older than this will be archived or deleted
                </p>
              </div>

              <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
                <p className="text-sm text-orange-500 font-medium mb-2">Storage Usage</p>
                <div className="w-full bg-background rounded-full h-2">
                  <div className="h-full bg-orange-500 rounded-full" style={{ width: '65%' }}></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">655 GB / 1000 GB used</p>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            className="w-full bg-primary hover:bg-primary/90"
            disabled={saveStatus === 'saving'}
          >
            <Save className="w-4 h-4 mr-2" />
            {saveStatus === 'saving' ? 'Saving...' : saveStatus === 'saved' ? t.saved : t.saveChanges}
          </Button>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          {/* Advanced Settings */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-bold text-foreground mb-4">{t.advancedSettings}</h3>
            <div className="space-y-3">
              <button className="w-full p-3 bg-background/50 rounded-lg hover:bg-background transition text-left font-medium text-primary text-sm">
                {t.apiKeys}
              </button>
              <button className="w-full p-3 bg-background/50 rounded-lg hover:bg-background transition text-left font-medium text-primary text-sm">
                {t.integrations}
              </button>
              <button className="w-full p-3 bg-background/50 rounded-lg hover:bg-background transition text-left font-medium text-destructive text-sm">
                Export Logs
              </button>
            </div>
          </div>

          {/* System Status */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-bold text-foreground mb-4">System Status</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">API Status</span>
                <Badge className="bg-green-500/20 text-green-500">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Database</span>
                <Badge className="bg-green-500/20 text-green-500">Connected</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Cache</span>
                <Badge className="bg-green-500/20 text-green-500">Active</Badge>
              </div>
            </div>
          </div>

          {/* Platform Info */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-bold text-foreground mb-4">Platform Info</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div>
                <p className="text-xs text-muted-foreground">Version</p>
                <p className="font-semibold text-foreground">1.0.0 (Enterprise)</p>
              </div>
              <div className="mt-3">
                <p className="text-xs text-muted-foreground">Last Updated</p>
                <p className="font-semibold text-foreground">2026-06-23</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
